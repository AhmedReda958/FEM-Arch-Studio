export { default as Home } from './Home';
export { default as About } from './About';
export { default as Portfolio } from './Portfolio';
export { default as Contact } from './Contact';